
//This gets overrides if the option to not unset asset conditions is set. 
ReturnForm.prototype.nextAction = function () {
console.log("Next Action (Returned) ");		
		this.returnAsset();
}



